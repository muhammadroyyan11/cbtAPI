CKEDITOR.plugins.setLang( 'html5audio', 'en', {
    button: 'Insert HTML5 audio',
    title: 'HTML5 audio',
    infoLabel: 'Audio info',
    urlMissing: 'Audio source URL is missing.',
} );

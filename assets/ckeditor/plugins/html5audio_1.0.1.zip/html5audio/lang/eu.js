CKEDITOR.plugins.setLang( 'html5audio', 'eu', {
    button: 'Txertatu HTML5 audioa',
    title: 'HTML5 audioa',
    infoLabel: 'Audioaren informazioa',
    urlMissing: 'Audioaren URLak ezin du hutsik egon.'
} );